# Trimly.io — Python Video Processing Backend

This backend handles the real video processing pipeline:
1. Download YouTube video via yt-dlp
2. Transcribe audio via Whisper AI
3. Cut clips at exact timestamps
4. Reframe 16:9 → 9:16 with FFmpeg
5. Burn captions onto video
6. Upload to Supabase Storage
7. Save clip records to database

## Tech Stack
- **FastAPI** — API server
- **yt-dlp** — YouTube video downloader
- **FFmpeg** — video cutting, reframing, caption burning
- **OpenAI Whisper** — audio transcription
- **Supabase** — database + file storage

## Deploy to Railway (Recommended, ~$5/month)

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "Trimly backend"
git remote add origin https://github.com/YOUR_USERNAME/trimly-backend
git push -u origin main
```

### Step 2 — Deploy on Railway
1. Go to railway.app
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your repo
4. Railway auto-detects the Dockerfile and deploys

### Step 3 — Set Environment Variables
In Railway dashboard → your service → Variables tab, add:

```
SUPABASE_URL=https://uyamigdooyejsmogxahh.supabase.co
SUPABASE_SERVICE_KEY=your_service_role_key_here
```

Get your service role key from:
Supabase Dashboard → Project Settings → API → service_role key

### Step 4 — Set up Supabase Storage
1. Go to Supabase → Storage
2. Create a new bucket called: trimly-clips
3. Make it PUBLIC so users can download clips

### Step 5 — Update Frontend
Add your Railway URL to the frontend:
```js
const BACKEND_URL = "https://your-app.up.railway.app"
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | / | Health check |
| GET | /health | Health check |
| POST | /process | Start processing job |
| GET | /status/{job_id} | Get job status |
| GET | /clips/{job_id} | Get output clips |

## Local Development
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Note: FFmpeg must be installed locally for development.
- Mac: `brew install ffmpeg`
- Ubuntu: `apt-get install ffmpeg`
