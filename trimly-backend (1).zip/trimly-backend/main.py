from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn, os

from processor import process_video_job
from supabase_client import supabase

app = FastAPI(title="Trimly.io Video Processor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class JobRequest(BaseModel):
    job_id: str
    youtube_url: str
    num_clips: int = 5
    clip_length: int = 30
    aspect_ratio: str = "9:16"
    captions: str = "auto"
    clips_data: list = []

@app.get("/")
def root():
    return {"status": "Trimly.io Video Processor", "version": "1.0.0"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/process")
async def process(req: JobRequest, background_tasks: BackgroundTasks):
    supabase.table("video_jobs").update({
        "status": "downloading", "progress": 5
    }).eq("id", req.job_id).execute()

    background_tasks.add_task(
        process_video_job,
        job_id=req.job_id,
        youtube_url=req.youtube_url,
        num_clips=req.num_clips,
        clip_length=req.clip_length,
        aspect_ratio=req.aspect_ratio,
        captions=req.captions,
        clips_data=req.clips_data
    )
    return {"message": "Processing started", "job_id": req.job_id}

@app.get("/status/{job_id}")
def get_status(job_id: str):
    result = supabase.table("video_jobs").select(
        "id,status,progress,error_message,video_title"
    ).eq("id", job_id).single().execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Job not found")
    return result.data

@app.get("/clips/{job_id}")
def get_clips(job_id: str):
    result = supabase.table("output_clips").select("*").eq("job_id", job_id).order("clip_number").execute()
    return {"clips": result.data or []}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port)
