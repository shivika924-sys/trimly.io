import os
from supabase import create_client, Client

SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://uyamigdooyejsmogxahh.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY", "")  # Use service role key for backend

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
