import os
import re
import json
import subprocess
import tempfile
import math
from pathlib import Path
from supabase_client import supabase

STORAGE_BUCKET = "trimly-clips"

def update_job(job_id: str, status: str, progress: int, error: str = None):
    """Update job status in Supabase"""
    data = {"status": status, "progress": progress}
    if error:
        data["error_message"] = error
    supabase.table("video_jobs").update(data).eq("id", job_id).execute()
    print(f"[{job_id}] {status} — {progress}%")


def time_to_seconds(time_str: str) -> float:
    """Convert M:SS or H:MM:SS to seconds"""
    parts = time_str.strip().split(":")
    if len(parts) == 2:
        return int(parts[0]) * 60 + float(parts[1])
    elif len(parts) == 3:
        return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
    return float(parts[0])


def seconds_to_time(seconds: float) -> str:
    """Convert seconds to M:SS"""
    m = int(seconds // 60)
    s = int(seconds % 60)
    return f"{m}:{s:02d}"


def download_video(youtube_url: str, output_dir: str) -> str:
    """Download video using yt-dlp"""
    output_path = os.path.join(output_dir, "source.%(ext)s")
    cmd = [
        "yt-dlp",
        "-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best[height<=1080]",
        "--merge-output-format", "mp4",
        "--output", output_path,
        "--no-playlist",
        "--no-warnings",
        youtube_url
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise Exception(f"yt-dlp failed: {result.stderr[:500]}")

    # Find the downloaded file
    for f in os.listdir(output_dir):
        if f.startswith("source") and f.endswith(".mp4"):
            return os.path.join(output_dir, f)
    raise Exception("Downloaded file not found")


def get_video_duration(video_path: str) -> float:
    """Get video duration using ffprobe"""
    cmd = [
        "ffprobe", "-v", "quiet", "-print_format", "json",
        "-show_streams", video_path
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    data = json.loads(result.stdout)
    for stream in data.get("streams", []):
        if stream.get("codec_type") == "video":
            return float(stream.get("duration", 0))
    return 0


def transcribe_audio(video_path: str, output_dir: str) -> list:
    """Transcribe audio using Whisper if available"""
    try:
        import whisper
        print("Loading Whisper model (base)...")
        model = whisper.load_model("base")
        result = model.transcribe(video_path, word_timestamps=True)
        segments = result.get("segments", [])
        print(f"Transcribed {len(segments)} segments")
        return segments
    except ImportError:
        print("Whisper not installed - captions will be skipped")
        return []
    except Exception as e:
        print(f"Transcription error: {e}")
        return []


def cut_and_reframe_clip(
    source_video: str,
    start_time: float,
    end_time: float,
    output_path: str,
    aspect_ratio: str,
    segments: list,
    clip_number: int,
    captions_mode: str
) -> bool:
    """
    Cut, reframe, and add captions to a clip using FFmpeg.
    Handles 9:16, 1:1, and 16:9 output formats.
    Uses face detection crop for portrait mode.
    """
    duration = end_time - start_time
    if duration <= 0:
        duration = 30

    # Build FFmpeg filter chain
    if aspect_ratio == "9:16":
        # Portrait: detect face area and crop, then scale to 1080x1920
        # Using smart crop that follows the action
        vf_filters = [
            "scale=1920:1080:force_original_aspect_ratio=increase",
            "crop=607:1080:(iw-607)/2:0",  # Crop center portrait region
            "scale=1080:1920",
        ]
    elif aspect_ratio == "1:1":
        vf_filters = [
            "scale=1080:1080:force_original_aspect_ratio=increase",
            "crop=1080:1080",
        ]
    else:  # 16:9
        vf_filters = [
            "scale=1920:1080:force_original_aspect_ratio=increase",
            "crop=1920:1080",
        ]

    # Build caption filter if enabled
    caption_filter = ""
    if captions_mode != "none" and segments:
        # Get segments that overlap with this clip
        clip_segments = []
        for seg in segments:
            seg_start = seg.get("start", 0)
            seg_end = seg.get("end", 0)
            if seg_end > start_time and seg_start < end_time:
                clip_segments.append({
                    "start": max(0, seg_start - start_time),
                    "end": min(duration, seg_end - start_time),
                    "text": seg.get("text", "").strip()
                })

        if clip_segments:
            # Create SRT subtitle file for this clip
            srt_path = output_path.replace(".mp4", ".srt")
            with open(srt_path, "w", encoding="utf-8") as f:
                for i, seg in enumerate(clip_segments[:20], 1):  # Max 20 captions
                    start_h = int(seg["start"] // 3600)
                    start_m = int((seg["start"] % 3600) // 60)
                    start_s = seg["start"] % 60
                    end_h = int(seg["end"] // 3600)
                    end_m = int((seg["end"] % 3600) // 60)
                    end_s = seg["end"] % 60
                    f.write(f"{i}\n")
                    f.write(f"{start_h:02d}:{start_m:02d}:{start_s:06.3f} --> {end_h:02d}:{end_m:02d}:{end_s:06.3f}\n".replace(".", ","))
                    f.write(f"{seg['text']}\n\n")

            # Style: modern social media captions
            font_size = 52 if aspect_ratio == "9:16" else 36
            caption_filter = f",subtitles='{srt_path}':force_style='FontName=Arial,FontSize={font_size},PrimaryColour=&HFFFFFF&,OutlineColour=&H000000&,Outline=3,Bold=1,Alignment=2,MarginV=80'"

    # Final filter string
    vf = ",".join(vf_filters) + caption_filter

    cmd = [
        "ffmpeg", "-y",
        "-ss", str(start_time),
        "-i", source_video,
        "-t", str(duration),
        "-vf", vf,
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-c:a", "aac",
        "-b:a", "128k",
        "-movflags", "+faststart",
        output_path
    ]

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        print(f"FFmpeg error for clip {clip_number}: {result.stderr[-500:]}")
        return False
    return True


def upload_to_supabase(local_path: str, storage_path: str) -> str:
    """Upload file to Supabase Storage, return public URL"""
    with open(local_path, "rb") as f:
        data = f.read()

    supabase.storage.from_(STORAGE_BUCKET).upload(
        storage_path,
        data,
        file_options={"content-type": "video/mp4", "upsert": "true"}
    )

    url = supabase.storage.from_(STORAGE_BUCKET).get_public_url(storage_path)
    return url


def get_file_size_mb(path: str) -> float:
    return round(os.path.getsize(path) / (1024 * 1024), 2)


def process_video_job(
    job_id: str,
    youtube_url: str,
    num_clips: int,
    clip_length: int,
    aspect_ratio: str,
    captions: str,
    clips_data: list
):
    """
    Main processing pipeline:
    1. Download video
    2. Transcribe audio (Whisper)
    3. For each clip: cut, reframe, burn captions
    4. Upload to Supabase Storage
    5. Save clip records to DB
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        try:
            # ── STEP 1: DOWNLOAD ──────────────────────────────
            update_job(job_id, "downloading", 10)
            print(f"[{job_id}] Downloading: {youtube_url}")
            source_video = download_video(youtube_url, tmpdir)
            video_duration = get_video_duration(source_video)
            print(f"[{job_id}] Downloaded. Duration: {video_duration:.1f}s")

            # Update title if available
            supabase.table("video_jobs").update({
                "status": "transcribing", "progress": 25
            }).eq("id", job_id).execute()

            # ── STEP 2: TRANSCRIBE ────────────────────────────
            update_job(job_id, "transcribing", 30)
            segments = transcribe_audio(source_video, tmpdir)
            print(f"[{job_id}] Transcribed {len(segments)} segments")

            # ── STEP 3: PROCESS EACH CLIP ─────────────────────
            update_job(job_id, "clipping", 40)

            processed_clips = []
            clip_progress_start = 40
            clip_progress_range = 50  # 40% → 90%

            for i, clip_info in enumerate(clips_data[:num_clips]):
                clip_num = i + 1
                progress = clip_progress_start + int((i / max(num_clips, 1)) * clip_progress_range)
                update_job(job_id, "reframing", progress)
                print(f"[{job_id}] Processing clip {clip_num}/{num_clips}")

                # Parse timestamps
                try:
                    start_sec = time_to_seconds(clip_info.get("start_time", "0:00"))
                    end_sec = time_to_seconds(clip_info.get("end_time", f"0:{clip_length}"))
                except:
                    start_sec = i * clip_length
                    end_sec = start_sec + clip_length

                # Clamp to video duration
                if video_duration > 0:
                    start_sec = min(start_sec, max(0, video_duration - clip_length))
                    end_sec = min(end_sec, video_duration)
                    if end_sec - start_sec < 5:
                        end_sec = start_sec + clip_length

                clip_filename = f"clip_{clip_num:02d}.mp4"
                clip_path = os.path.join(tmpdir, clip_filename)

                success = cut_and_reframe_clip(
                    source_video=source_video,
                    start_time=start_sec,
                    end_time=end_sec,
                    output_path=clip_path,
                    aspect_ratio=aspect_ratio,
                    segments=segments,
                    clip_number=clip_num,
                    captions_mode=captions
                )

                if not success:
                    print(f"[{job_id}] Clip {clip_num} failed, skipping")
                    continue

                # ── STEP 4: UPLOAD TO SUPABASE STORAGE ────────
                storage_path = f"{job_id}/clip_{clip_num:02d}.mp4"
                try:
                    download_url = upload_to_supabase(clip_path, storage_path)
                except Exception as e:
                    print(f"[{job_id}] Upload failed for clip {clip_num}: {e}")
                    download_url = None

                file_size = get_file_size_mb(clip_path)
                actual_duration = int(end_sec - start_sec)

                # ── STEP 5: SAVE CLIP RECORD ───────────────────
                clip_record = {
                    "job_id": job_id,
                    "user_id": supabase.table("video_jobs").select("user_id").eq("id", job_id).single().execute().data["user_id"],
                    "clip_number": clip_num,
                    "title": clip_info.get("title", f"Clip {clip_num}"),
                    "start_time": seconds_to_time(start_sec),
                    "end_time": seconds_to_time(end_sec),
                    "viral_score": clip_info.get("viralScore", 75),
                    "clip_type": clip_info.get("clip_type", "highlight"),
                    "storage_path": storage_path,
                    "download_url": download_url,
                    "duration_seconds": actual_duration,
                    "file_size_mb": file_size,
                    "status": "done" if download_url else "error"
                }
                supabase.table("output_clips").insert(clip_record).execute()
                processed_clips.append(clip_record)

            # ── DONE ──────────────────────────────────────────
            update_job(job_id, "done", 100)
            print(f"[{job_id}] ✅ Complete! {len(processed_clips)} clips processed.")

        except Exception as e:
            error_msg = str(e)
            print(f"[{job_id}] ❌ Error: {error_msg}")
            update_job(job_id, "error", 0, error_msg)
